﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernate.Tool.hbm2ddl;

namespace Teste.Models
{
    public class NHibernateHelper
    {
        public static ISession OpenSession()
        {
            ISessionFactory sessionFactory = Fluently.Configure()
                .Database(MsSqlConfiguration.MsSql2012
                  //.ConnectionString(@"Data Source=(LAB18-15)\v11.0;AttachDbFilename=C:\Users\Aluno\Desktop\Teste\Teste\App_Data\Banco.mdf;Integrated Security=True")
                  .ConnectionString(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Aluno\Desktop\Teste\Teste\App_Data\Banco.mdf;Integrated Security=True")
                              .ShowSql()
                )
               .Mappings(m =>
                          m.FluentMappings
                              .AddFromAssemblyOf<Employee>())
                .ExposeConfiguration(cfg => new SchemaExport(cfg)
                                                .Create(false, false))
                .BuildSessionFactory();
            return sessionFactory.OpenSession();


            //   <add name="EntidadesContext" connectionString="Data Source=    (LocalDB)\MSSQLLocalDB;AttachDbFilename=|path|\LojaEF.mdf;Integrated Security=True" providerName="System.Data.SqlClient" />


            //connectionString="Server=<endereco do banco>,<porta>;Database=<nome da base de dados>;User Id=<login do usuario>;Password=<senha do usuario>;"
        }
    }
}