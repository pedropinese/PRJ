﻿using ControleEstoque.Web.Models;
using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Teste.Models;

namespace ControleEstoque.Web.Controllers
{
    public class FornecedorController : Controller
    {
        // GET: Fornecedor
        public ActionResult Listar(string busca)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var fornecedores = session.Query<Fornecedor>().OrderBy(f => f.Nome).ToList();

                if (!string.IsNullOrEmpty(busca))
                {
                    fornecedores = session.Query<Fornecedor>().Where(f => f.Nome.Contains(busca)).OrderBy(f => f.Nome).ToList();
                }

                return View(fornecedores);

            }
        }

        // GET: Fornecedor/Create
        public ActionResult Adicionar()
        {
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        public ActionResult Adicionar(Fornecedor fornecedor)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(fornecedor);
                        transaction.Commit();
                    }
                }

                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }

        // GET: Fornecedor/Editar/5
        public ActionResult Editar(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var fornecedor = session.Get<Fornecedor>(id);
                return View(fornecedor);
            }
        }

        // POST: Employee/Editar/5
        [HttpPost]
        public ActionResult Editar(int id, Fornecedor fornecedor)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    var fornecedortoUpdate = session.Get<Fornecedor>(id);

                    fornecedortoUpdate.Nome = fornecedor.Nome;
                    fornecedortoUpdate.Cep = fornecedor.Cep;
                    fornecedortoUpdate.Telefone = fornecedor.Telefone;
                    fornecedortoUpdate.Cpf = fornecedor.Cpf;
                    fornecedortoUpdate.Rg = fornecedor.Rg;
                    fornecedortoUpdate.Cnpj = fornecedor.Cnpj;
                    fornecedortoUpdate.Ie = fornecedor.Ie;

                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(fornecedortoUpdate);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch
            {
                return View();
            }
        }

        // GET: Fornecedor/Excluir/5
        public ActionResult Excluir(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var fornecedor = session.Get<Fornecedor>(id);
                return View(fornecedor);
            }
        }

        [HttpPost]
        public ActionResult Excluir(int id, Fornecedor fornecedor)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Delete(fornecedor);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }
    }
}
