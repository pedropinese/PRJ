﻿using ControleEstoque.Web.Models;
using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Teste.Models;

namespace ControleEstoque.Web.Controllers
{
    public class MarcaProdutoController : Controller
    {
        // GET: MarcaProduto
        public ActionResult Listar(string busca)
        {
            using (NHibernate.ISession session = NHibernateHelper.OpenSession())
            {
                var marcas = session.Query<MarcaProduto>().OrderBy(m => m.Nome).ToList();

                if (!string.IsNullOrEmpty(busca))
                {
                    marcas = session.Query<MarcaProduto>().Where(m => m.Nome.Contains(busca)).OrderBy(c => c.Nome).ToList();
                }

                return View(marcas);
            }
        }


        // GET: MarcaProduto/Create
        public ActionResult Adicionar()
        {
            return View();
        }

        // POST: MarcaProduto/Create
        [HttpPost]
        public ActionResult Adicionar(MarcaProduto marcas)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(marcas);
                        transaction.Commit();
                    }
                }

                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }

        // GET: MarcaProduto/Edit/5
        public ActionResult Editar(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var marcas = session.Get<MarcaProduto>(id);
                return View(marcas);
            }
        }

        // POST
        [HttpPost]
        public ActionResult Editar(int id, MarcaProduto marcas)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    var marcatoUpdate = session.Get<MarcaProduto>(id);

                    marcatoUpdate.Nome = marcas.Nome;

                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(marcatoUpdate);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch
            {
                return View();
            }
        }

        // GET: Cliente/Delete/5
        public ActionResult Excluir(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var marcas = session.Get<MarcaProduto>(id);
                return View(marcas);
            }
        }

        [HttpPost]
        public ActionResult Excluir(int id, MarcaProduto marcas)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Delete(marcas);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }
    }
}
