﻿using ControleEstoque.Web.Models;
using ControleEstoque.Web.Models.ViewModels;
using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Teste.Models;

namespace ControleEstoque.Web.Controllers
{
    public class CompraController : Controller
    {
        CompraProdutoViewModel viewModel = new CompraProdutoViewModel(); // instancia a viewModel que sera usada pelo adicionar


        // GET: Compra
        public ActionResult Listar()
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var compras = session.Query<Compra>().OrderBy(c => c.Id).ToList();
                return View(compras);
            }
        }

        // GET: Compra/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }


        // GET: Compra/Create
        public ActionResult Adicionar()
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                viewModel.listaProdutos = session.Query<Produto>().OrderBy(p => p.Registro).ToList();
            }
            return View(viewModel);
        }


        // POST: Compra/Create
        [HttpPost]
        public ActionResult Adicionar(int? id, int? listaBusca, string busca, Compra compra)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    viewModel.listaProdutos = session.Query<Produto>().OrderBy(p => p.Registro).ToList();

                    if (id != null)
                    {
                        viewModel.listaProdutosCompra = new List<Produto>();
                        var produto = session.Get<Produto>(id);
                        viewModel.listaProdutosCompra.Add(produto);
                        return View();
                    }

                    //se o campo tiver alguma coisa, pegue-a e faça o switch
                    if (!string.IsNullOrEmpty(busca))
                    {
                        if (viewModel.listaProdutos.Equals(null))
                        {
                            viewModel.listaProdutos = session.Query<Produto>().OrderBy(p => p.Registro).ToList();
                        }
                        switch (listaBusca)
                        {
                            case 1:
                                viewModel.listaProdutos = session.Query<Produto>().Where(p => p.Registro.Contains(busca)).OrderBy(p => p.Registro).ToList();

                                break;

                            case 2:
                                viewModel.listaProdutos = session.Query<Produto>().Where(p => p.Marca.Contains(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            case 3:
                                viewModel.listaProdutos = session.Query<Produto>().Where(p => p.Valor.Equals(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            case 4:
                                viewModel.listaProdutos = session.Query<Produto>().Where(p => p.Dot.Contains(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            case 5:
                                viewModel.listaProdutos = session.Query<Produto>().Where(p => p.Serie.Contains(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            case 6:
                                viewModel.listaProdutos = session.Query<Produto>().Where(p => p.Medida.Contains(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            case 7:
                                viewModel.listaProdutos = session.Query<Produto>().Where(p => p.Desenho.Contains(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            default:
                                break;
                        }
                    }
                    using (ITransaction transaction = session.BeginTransaction())
                    {

                        session.Save(compra);
                        transaction.Commit();
                    }

                }
                return View(viewModel);
                
                //return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {

                return View();
            }
        }

        // GET: Compra/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Compra/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Compra/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Compra/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

    }
}
