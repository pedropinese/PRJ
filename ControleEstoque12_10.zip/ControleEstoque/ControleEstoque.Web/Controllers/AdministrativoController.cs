﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ControleEstoque.Web.Controllers
{
    public class AdministrativoController : Controller
    {
        // GET: Administrativo
        [Authorize]
        public ActionResult CriarUsuario()
        {
            return View();
        }

        [Authorize]
        public ActionResult EditarUsuario()
        {
            return View();
        }

        [Authorize]
        public ActionResult ExcluirUsuario()
        {
            return View();
        }

        [Authorize]
        public ActionResult ContasPagar()
        {
            return View();
        }

        [Authorize]
        public ActionResult ContasReceber()
        {
            return View();
        }


    }
}