﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models
{
    public class MarcaProdutoMap : ClassMap<MarcaProduto>
    {
        public MarcaProdutoMap()
        {
            Id(x => x.Id);
            Map(x => x.Nome);
            Table("MarcaProduto");
        }
    }
}