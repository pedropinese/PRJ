﻿using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Teste.Models;

namespace ControleEstoque.Web.Models
{
    public class MarcaProduto
    {
        [Display(Name = "ID")]
        public virtual int Id { get; set; }

        [Display(Name = "Nome")]
        public virtual string Nome { get; set; }

        public virtual List<MarcaProduto> listarMarcas()
        {
            List<MarcaProduto> lista = new List<MarcaProduto>();

            using (ISession session = NHibernateHelper.OpenSession())
            {
                lista = session.Query<MarcaProduto>().OrderBy(m => m.Nome).ToList();
                
            }
            return lista;
        }
    }
}