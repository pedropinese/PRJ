﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FluentNHibernate.Mapping;

namespace ControleEstoque.Web.Models
{
    public class ProdutoMap : ClassMap<Produto>
    {
        public ProdutoMap()
        {
            Id(x => x.Id);
            Map(x => x.Registro);
            Map(x => x.Marca);
            Map(x => x.Valor);
            Map(x => x.Dot);
            Map(x => x.Serie);
            Map(x => x.Medida);
            Map(x => x.Desenho);
            Map(x => x.Quantidade);
            Table("Produto");
        }

    }

  
}