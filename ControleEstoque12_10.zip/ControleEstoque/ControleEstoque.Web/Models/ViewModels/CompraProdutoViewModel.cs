﻿using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Teste.Models;

namespace ControleEstoque.Web.Models.ViewModels
{
    public class CompraProdutoViewModel
    {

        public Compra compra { get; set; }
        
        public Produto produto { get; set; }

        [Display(Name = "Lista de Produtos")]
        public List<Produto> listaProdutos { get; set; }

        [Display(Name = "Lista de Produtos")]
        public List<Produto> listaProdutosCompra { get; set; }

        public CompraProdutoViewModel()
        {
            listaProdutosCompra = new List<Produto>();
            listaProdutos = new List<Produto>();
            carregaLista();
        }

        public void carregaLista()
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                listaProdutos = session.Query<Produto>().OrderBy(p => p.Id).ToList();
            }
        }
       
    }
}