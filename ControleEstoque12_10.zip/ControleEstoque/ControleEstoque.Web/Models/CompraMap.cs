﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models
{
    public class CompraMap : ClassMap<Compra>
    {
        public CompraMap()
        {
            Id(x => x.Id);
            Map(x => x.Id_fornecedor);
            Map(x => x.Categoria);
            Map(x => x.Valor);
            Map(x => x.Id_usuario);
            Map(x => x.Data).Column("data_compra").CustomType("DateTime").Access.Property().Generated.Never().CustomSqlType("DATE").Not.Nullable();
            Table("Compra");
        }

    }
}