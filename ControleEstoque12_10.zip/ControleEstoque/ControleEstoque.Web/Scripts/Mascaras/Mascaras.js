﻿$(document).ready(function () {
    $('.date').mask('00/00/0000');
    $('.time').mask('00:00:00');
    $('.date_time').mask('00/00/0000 00:00:00');
    $('.cep').mask('00000-000');
    $('.phone').mask('0000-0000');
    $('.phone_with_ddd').mask('(00) 0000-0000');
    $('.phone_us').mask('(000) 000-0000');    
    $('.phone_br').focusout(function () {
        var phone, element;
        element = $(this);
        element.unmask();
        phone = element.val().replace(/\D/g, '');
        if (phone.length > 10) {
            element.mask("(99) 99999-9999");
        } else {
            element.mask("(99) 9999-99999");
        }
    }).trigger('focusout');
    $('.data').focusout(function () {
        var date, element;
        element = $(this);
        element.unmask();
        date = element.val().replace(/\D/g, '');
        if (date.length > 10) {
            element.mask("00/00/0000 00:00:00");
        } else {
            element.mask("00/00/0000");
        }
    }).trigger('focusout');
    $('.mixed').mask('AAA 000-S0S');
    $('.cpf').mask('000.000.000-00');
    $('.rg').mask('00.000.000-0');
    $('.cnpj').mask('00.000.000/0000-00');
    $('.ie').mask('000.000.000.000');
    $('.money').mask('000.000.000.000.000,00');
    $('.money2').mask("##.###.##0,00");
    $('.integer').mask("#.##0", { reverse: true });
    $('.int').mask("0000", { reverse: true });
    $('.ip_address').mask('0ZZ.0ZZ.0ZZ.0ZZ', {
        translation: {
            'Z': {
                pattern: /[0-9]/, optional: true
            }
        }
    });
    $('.ip_address').mask('099.099.099.099');
    $('.percent').mask('##0,00%', { reverse: true });
    $('.clear-if-not-match').mask("00/00/0000", { clearIfNotMatch: true });
    $('.placeholder').mask("00/00/0000", { placeholder: "__/__/____" });
    $('.fallback').mask("00r00r0000", {
        translation: {
            'r': {
                pattern: /[\/]/,
                fallback: '/'
            },
            placeholder: "__/__/____"
        }
    });
    $('.selectonfocus').mask("00/00/0000", { selectOnFocus: true });
    $(".uppercase").keyup(function (e) {
        var start = e.target.selectionStart;
        e.target.value = e.target.value.toUpperCase();
        e.target.selectionStart = e.target.selectionEnd = start;
    });
    $('.maiusculo').mask('SSSSSSSSSSSS', {
        'translation': {
            S: { pattern: /[A-Za-z0-9]/ }
        },
        onKeyPress: function (value, event) {
            event.currentTarget.value = value.toUpperCase();
        }
    });
});