﻿using ControleEstoque.Web.Models;
using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Teste.Models;

namespace ControleEstoque.Web.Controllers
{
    public class ProdutoController : Controller
    {
        // GET: Produto
        public ActionResult Consultar()
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var produtos = session.Query<Produto>().ToList();
                return View(produtos);
            }
        }

        // GET: Produto/Details/5
        public ActionResult Detalhes(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var produto = session.Get<Produto>(id);
                return View(produto);
            }
        }

        // GET: Produto/Create
        public ActionResult Adicionar()
        {
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        public ActionResult Adicionar(Produto produto)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(produto);
                        transaction.Commit();
                    }
                }

                return RedirectToAction("Consultar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }

        // GET: Produto/Edit/5
        public ActionResult Editar(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var produto = session.Get<Produto>(id);
                return View(produto);
            }
        }

        // POST: Employee/Edit/5
        [HttpPost]
        public ActionResult Editar(int id, Produto produto)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    var produtotoUpdate = session.Get<Produto>(id);

                    produtotoUpdate.Registro = produto.Registro;
                    produtotoUpdate.Marca = produto.Marca;
                    produtotoUpdate.Valor = produto.Valor;
                    produtotoUpdate.Dot = produto.Dot;
                    produtotoUpdate.Serie = produto.Serie;
                    produtotoUpdate.Medida = produto.Medida;
                    produtotoUpdate.Desenho = produto.Desenho;
                    produtotoUpdate.Quantidade = produto.Quantidade;

                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(produtotoUpdate);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Consultar");
            }
            catch
            {
                return View();
            }
        }

        // GET: Produto/Delete/5
        public ActionResult Excluir(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var produto = session.Get<Produto>(id);
                return View(produto);
            }
        }

        [HttpPost]
        public ActionResult Excluir(int id, Produto produto)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Delete(produto);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Consultar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }
    }
}
