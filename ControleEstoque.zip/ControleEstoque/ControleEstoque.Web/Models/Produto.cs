﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models
{
    public class Produto
    {
        public virtual int Id { get; set; }
        public virtual string Registro { get; set; }
        public virtual string Marca { get; set; }
        public virtual double Valor { get; set; }
        public virtual string Dot { get; set; }
        public virtual string Serie { get; set; }
        public virtual string Medida { get; set; }
        public virtual string Desenho { get; set; }
        public virtual int Quantidade { get; set; }

        
    }
}