﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models
{
    public class Fornecedor
    {
        [Display(Name = "ID")]
        public virtual int Id { get; set; }

        [Display(Name = "Nome")]
        public virtual string Nome { get; set; }

        [Display(Name = "CEP")]
        public virtual string Cep { get; set; }

        [Display(Name = "Telefone")]
        public virtual string Telefone { get; set; }

        [Display(Name = "CPF")]
        public virtual string Cpf { get; set; }

        [Display(Name = "RG")]
        public virtual string Rg { get; set; }

        [Display(Name = "CNPJ")]
        public virtual string Cnpj { get; set; }

        [Display(Name = "Inscrição Estadual")]
        public virtual string Ie { get; set; }
    }
}