﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernate.Tool.hbm2ddl;
using ControleEstoque.Web.Models;
using NHibernate.Cfg;

namespace Teste.Models
{
    public class NHibernateHelper
    {

        public static ISession OpenSession()
        {
            ISessionFactory sessionFactory = Fluently.Configure().
                Database(MySQLConfiguration.Standard.
                    ConnectionString("Server=localhost; Port=3306; Database = brpneus_bd; Uid = root; SslMode=none; Pwd =; ")
                              .ShowSql()
                )
               .Mappings(m =>
                          m.FluentMappings
                              .AddFromAssemblyOf<Produto>())
                .ExposeConfiguration(cfg => new SchemaExport(cfg)
                                                .Create(false, false))
                .BuildSessionFactory();
            return sessionFactory.OpenSession();
        }
    }
}