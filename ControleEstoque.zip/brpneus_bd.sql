create database brpneus_bd;
use brpneus_bd;

create table Produto(
	id int not null auto_increment primary key,
    registro varchar(10),
    marca varchar(30),
    valor double(9,2),
    dot varchar(5),
    serie varchar(15),
    medida varchar(15),
    desenho varchar(20),
    quantidade int 
    );


insert into Produto(registro, marca, valor, dot, serie, medida, desenho) values 
('R1', 'MARSHAL', 250.00, '4814', 'E4629', '295/80 R22', 'LISO'),
('R2', 'GOODYEAR', 250.00, '2811', '207', '295/80 R22', 'LISO'),
('R6', 'MICHELIN', 250.00, '3615', '18411', '295/80 R22', 'BORRACHUDO');

create table Fornecedor(
	id int not null auto_increment primary key,
    nome varchar(55),
    cep varchar(10),
    telefone varchar(15),
    cpf varchar(15),
    rg varchar(12),
    cnpj varchar(18),
    ie varchar(15)
    );
    
    
    insert into Fornecedor(nome, cep, telefone, cpf, rg, cnpj, ie) values 
('RP Pneus', '13424480', '1999726-1520', '', '', '11715186000181', ''),
('Murilo Capelari', '13425120', '1934267985', '48546259877', '569856632', '', '');
    
    create table Cliente(
	id int not null auto_increment primary key,
    nome varchar(55),
    cep varchar(10),
    telefone varchar(15),
    cpf varchar(15),
    rg varchar(12),
    cnpj varchar(18),
    ie varchar(15)
    );
    
    insert into Cliente(nome, cep, telefone, cpf, rg, cnpj, ie) values 
('João Damiani', '13401555', '19997486578', '48575878596', '528659858', '', ''),
('Leo Garcia', '13425120', '1934265898', '52689878484', '946518616', '', ''),
('Nho-Quim Pneus', '13425380', '1934227046', '', '', '49398423000109', '');
    
    select * from fornecedor;
    select * from produto;
    select * from cliente;
    
    
    
    