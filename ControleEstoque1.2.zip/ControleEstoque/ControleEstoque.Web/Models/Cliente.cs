﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models
{
    public class Cliente
    {
        [Display(Name = "ID")]
        public virtual int Id { get; set; }

        [Required(ErrorMessage = "Insira o nome do cliente", AllowEmptyStrings = false)]
        [Display(Name = "Nome")]
        public virtual string Nome { get; set; }

        [StringLength(9, MinimumLength = 9)]
        [Display(Name = "CEP")]
        public virtual string Cep { get; set; }

        [Display(Name = "Telefone")]
        public virtual string Telefone { get; set; }

        [Display(Name = "CPF")]
        public virtual string Cpf { get; set; }

        [Display(Name = "RG")]
        public virtual string Rg { get; set; }
        
        [Display(Name = "CNPJ")]
        public virtual string Cnpj { get; set; }

        [Display(Name = "Inscrição Estadual")]
        public virtual string Ie { get; set; }
    }
}