﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models
{
    public class Produto
    {
        public virtual int Id { get; set; }

        [Required(ErrorMessage = "Insira o número de registro", AllowEmptyStrings = false)]
        [Display(Name = "Registro")]
        public virtual string Registro { get; set; }

        [Required(ErrorMessage = "Insira a marca", AllowEmptyStrings = false)]
        [Display(Name = "Marca")]
        public virtual string Marca { get; set; }

        [Required(ErrorMessage = "Insira o valor", AllowEmptyStrings = false)]
        [Display(Name = "Valor")]
        public virtual double Valor { get; set; }

        [Required(ErrorMessage = "Insira o código DOT", AllowEmptyStrings = false)]
        [Display(Name = "DOT")]
        public virtual string Dot { get; set; }

        [Required(ErrorMessage = "Insira o número de série", AllowEmptyStrings = false)]
        [Display(Name = "Serie")]
        public virtual string Serie { get; set; }

        [Required(ErrorMessage = "Insira a medida", AllowEmptyStrings = false)]
        [Display(Name = "Medida")]
        public virtual string Medida { get; set; }

        [Required(ErrorMessage = "Selecione o desenho", AllowEmptyStrings = false)]
        [Display(Name = "Desenho")]
        public virtual string Desenho { get; set; }

        public virtual int Quantidade { get; set; }

        //public int CategoriaSelecionada { get; set; }
    }
}