﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models
{
    public class ClienteMap : ClassMap<Cliente>
    {
        public ClienteMap()
        {
            Id(x => x.Id);
            Map(x => x.Nome);
            Map(x => x.Cep);
            Map(x => x.Telefone);
            Map(x => x.Cpf);
            Map(x => x.Rg);
            Map(x => x.Cnpj);
            Map(x => x.Ie);
            Table("Cliente");
        }

    }
}