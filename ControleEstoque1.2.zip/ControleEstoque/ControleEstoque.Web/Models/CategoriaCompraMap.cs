﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models
{
    public class CategoriaCompraMap : ClassMap<CategoriaCompra>
    {
        public CategoriaCompraMap()
        {
            Id(x => x.Id);
            Map(x => x.Nome);
            Table("CategoriaCompra");
        }

    }
}