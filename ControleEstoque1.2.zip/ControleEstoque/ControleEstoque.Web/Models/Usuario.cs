﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models
{
    public class Usuario
    {
        [Display(Name = "ID")]
        public virtual int Id { get; set; }

        [Display(Name = "Nome")]
        public virtual string Nome { get; set; }

        [Display(Name = "Senha")]
        public virtual string Senha { get; set; }

        [Display(Name = "Tipo")]
        public virtual string Tipo { get; set; }
    }
}