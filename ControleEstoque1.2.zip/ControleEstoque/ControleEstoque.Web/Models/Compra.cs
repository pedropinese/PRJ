﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models
{
    public class Compra
    {
        [Display(Name = "ID")]
        public virtual int Id { get; set; }

        [Display(Name = "Fornecedor")]
        public virtual int Id_fornecedor { get; set; }

        [Display(Name = "Categoria")]
        public virtual string Categoria { get; set; }

        [Display(Name = "Valor")]
        public virtual double Valor { get; set; }

        [Display(Name = "Usuário")]
        public virtual int Id_usuario { get; set; }

        [Display(Name = "Data")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public virtual DateTime? Data { get; set; }
    }
}