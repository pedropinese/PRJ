﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models.ViewModels
{
    public class CompraProdutoViewModel
    {

        public Compra compra { get; set; }
        
        public Produto produto { get; set; }

        public List<Produto> listaProdutos { get; set; }

        public  int categoriaSelecionada { get; set; }

    }
}