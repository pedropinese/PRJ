﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ControleEstoque.Web.Models
{
    public class MarcaProduto
    {
        [Display(Name = "ID")]
        public virtual int Id { get; set; }

        [Display(Name = "Nome")]
        public virtual string Nome { get; set; }
    }
}