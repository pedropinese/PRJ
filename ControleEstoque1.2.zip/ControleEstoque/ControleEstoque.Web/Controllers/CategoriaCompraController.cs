﻿using ControleEstoque.Web.Models;
using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Teste.Models;

namespace ControleEstoque.Web.Controllers
{
    public class CategoriaCompraController : Controller
    {
        public ActionResult Listar(string busca)
        {
            using (NHibernate.ISession session = NHibernateHelper.OpenSession())
            {
                var categoria = session.Query<CategoriaCompra>().OrderBy(m => m.Nome).ToList();

                if (!string.IsNullOrEmpty(busca))
                {
                    categoria = session.Query<CategoriaCompra>().Where(m => m.Nome.Contains(busca)).OrderBy(c => c.Nome).ToList();
                }

                return View(categoria);
            }
        }


        // GET: MarcaProduto/Create
        public ActionResult Adicionar()
        {
            return View();
        }

        // POST: MarcaProduto/Create
        [HttpPost]
        public ActionResult Adicionar(CategoriaCompra categoria)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(categoria);
                        transaction.Commit();
                    }
                }

                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }

        // GET: MarcaProduto/Edit/5
        public ActionResult Editar(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var categoria = session.Get<CategoriaCompra>(id);
                return View(categoria);
            }
        }

        // POST
        [HttpPost]
        public ActionResult Editar(int id, CategoriaCompra categoria)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    var categoriatoUpdate = session.Get<CategoriaCompra>(id);

                    categoriatoUpdate.Nome = categoria.Nome;

                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(categoriatoUpdate);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch
            {
                return View();
            }
        }

        // GET: Cliente/Delete/5
        public ActionResult Excluir(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var categoria = session.Get<CategoriaCompra>(id);
                return View(categoria);
            }
        }

        [HttpPost]
        public ActionResult Excluir(int id, CategoriaCompra categoria)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Delete(categoria);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }
    }
}
