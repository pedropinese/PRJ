﻿using ControleEstoque.Web.Models;
using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Teste.Models;

namespace ControleEstoque.Web.Controllers
{
    public class UsuarioController : Controller
    {
        // GET: Usuario
        public ActionResult Listar()
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var clientes = session.Query<Usuario>().OrderBy(u => u.Nome).ToList();

                return View(clientes);
            }
        }

        // GET: Usuario/Create
        public ActionResult Adicionar()
        {
            return View();
        }

        // POST: Usuario/Create
        [HttpPost]
        public ActionResult Adicionar(Usuario usuario)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(usuario);
                        transaction.Commit();
                    }
                }

                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }

        // GET: Produto/Edit/5
        public ActionResult Editar(int id)
        {


            using (ISession session = NHibernateHelper.OpenSession())
            {
                var usuario = session.Get<Usuario>(id);
                return View(usuario);
            }
        }

        // POST: Employee/Edit/5
        [HttpPost]
        public ActionResult Editar(int id, Usuario usuario)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    var usuariotoUpdate = session.Get<Usuario>(id);

                    usuariotoUpdate.Nome = usuario.Nome;
                    usuariotoUpdate.Senha = usuario.Senha;
                    usuariotoUpdate.Tipo = usuario.Tipo;

                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(usuariotoUpdate);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch
            {
                return View();
            }
        }

        // GET: Produto/Delete/5
        public ActionResult Excluir(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var usuario = session.Get<Usuario>(id);
                return View(usuario);
            }
        }


        // POST: Produto/Delete/5
        [HttpPost]
        public ActionResult Excluir(int id, Usuario usuario)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Delete(usuario);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }
    }
}
