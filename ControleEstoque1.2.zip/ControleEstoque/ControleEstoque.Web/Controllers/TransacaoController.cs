﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ControleEstoque.Web.Controllers
{
    public class TransacaoController : Controller
    {
        // GET: Transacao
        [Authorize]
        public ActionResult Compra()
        {
            return View();
        }

        [Authorize]
        public ActionResult Venda()
        {
            return View();
        }
    }
}