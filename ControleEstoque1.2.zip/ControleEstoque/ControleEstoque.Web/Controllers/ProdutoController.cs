﻿using ControleEstoque.Web.Models;
using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Teste.Models;

namespace ControleEstoque.Web.Controllers
{
    public class ProdutoController : Controller
    {
        // GET: Produto
        public ActionResult Listar(int? listaBusca, string busca)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var produtos = session.Query<Produto>().OrderBy(c => c.Registro).ToList();

                if (!string.IsNullOrEmpty(busca))
                {
                    //se o campo tiver alguma coisa, pegue-a e faça o switch
                    if (!string.IsNullOrEmpty(busca))
                    {
                        if (produtos.Equals(null))
                        {
                            produtos = session.Query<Produto>().OrderBy(p => p.Registro).ToList();
                        }
                        switch (listaBusca)
                        {
                            case 1:
                                produtos = session.Query<Produto>().Where(p => p.Registro.Contains(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            case 2:
                                produtos = session.Query<Produto>().Where(p => p.Marca.Contains(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            case 3:
                                produtos = session.Query<Produto>().Where(p => p.Valor.Equals(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            case 4:
                                produtos = session.Query<Produto>().Where(p => p.Dot.Contains(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            case 5:
                                produtos = session.Query<Produto>().Where(p => p.Serie.Contains(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            case 6:
                                produtos = session.Query<Produto>().Where(p => p.Medida.Contains(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            case 7:
                                produtos = session.Query<Produto>().Where(p => p.Desenho.Contains(busca)).OrderBy(p => p.Registro).ToList();
                                break;

                            default:
                                break;
                        }
                    }
                }

                return View(produtos);

            }
        }

        // GET: Produto/Create
        public ActionResult Adicionar()
        {
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        public ActionResult Adicionar(Produto produto)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        produto.Quantidade = 1;
                        session.Save(produto);
                        transaction.Commit();
                    }
                }

                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }

        // GET: Produto/Edit/5
        public ActionResult Editar(int id)
        {


            using (ISession session = NHibernateHelper.OpenSession())
            {
                var produto = session.Get<Produto>(id);
                return View(produto);
            }
        }

        // POST: Employee/Edit/5
        [HttpPost]
        public ActionResult Editar(int id, Produto produto)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    var produtotoUpdate = session.Get<Produto>(id);

                    produtotoUpdate.Registro = produto.Registro;
                    produtotoUpdate.Marca = produto.Marca;
                    produtotoUpdate.Valor = produto.Valor;
                    produtotoUpdate.Dot = produto.Dot;
                    produtotoUpdate.Serie = produto.Serie;
                    produtotoUpdate.Medida = produto.Medida;
                    produtotoUpdate.Desenho = produto.Desenho;
                    produtotoUpdate.Quantidade = 1;

                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(produtotoUpdate);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch
            {
                return View();
            }
        }

        // GET: Produto/Delete/5
        public ActionResult Excluir(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var produto = session.Get<Produto>(id);
                return View(produto);
            }
        }

        [HttpPost]
        public ActionResult Excluir(int id, Produto produto)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Delete(produto);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }
    }
}
