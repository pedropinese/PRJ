﻿using ControleEstoque.Web.Models;
using NHibernate;
using NHibernate.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Teste.Models;

namespace ControleEstoque.Web.Controllers
{
    public class ClienteController : Controller
    {
        public ActionResult Listar( string busca )
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var clientes = session.Query<Cliente>().OrderBy(c => c.Nome).ToList();

                if (!string.IsNullOrEmpty(busca))
                {
                    clientes = session.Query<Cliente>().Where(c => c.Nome.Contains(busca)).OrderBy(c => c.Nome).ToList();
                }
                
                return View(clientes);

            }
        }

        // GET: Cliente/Create
        public ActionResult Adicionar()
        {
            return View();
        }

        // POST: Employee/Create
        [HttpPost]
        public ActionResult Adicionar(Cliente cliente)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(cliente);
                        transaction.Commit();
                    }
                }

                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }

        // GET: Cliente/Edit/5
        public ActionResult Editar(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var clientes = session.Get<Cliente>(id);
                return View(clientes);
            }
        }

        // POST: Employee/Edit/5
        [HttpPost]
        public ActionResult Editar(int id, Cliente cliente)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    var clientetoUpdate = session.Get<Cliente>(id);

                    clientetoUpdate.Nome = cliente.Nome;
                    clientetoUpdate.Cep = cliente.Cep;
                    clientetoUpdate.Telefone = cliente.Telefone;
                    clientetoUpdate.Cpf = cliente.Cpf;
                    clientetoUpdate.Rg = cliente.Rg;
                    clientetoUpdate.Cnpj = cliente.Cnpj;
                    clientetoUpdate.Ie = cliente.Ie;

                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(clientetoUpdate);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch
            {
                return View();
            }
        }

        // GET: Cliente/Delete/5
        public ActionResult Excluir(int id)
        {
            using (ISession session = NHibernateHelper.OpenSession())
            {
                var clientes = session.Get<Cliente>(id);
                return View(clientes);
            }
        }

        [HttpPost]
        public ActionResult Excluir(int id, Cliente cliente)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Delete(cliente);
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Listar");
            }
            catch (Exception exception)
            {
                return View();
            }
        }
    }
}
